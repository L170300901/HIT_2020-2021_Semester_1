#include <stdio.h>
#include <stdlib.h>

void main(){
    printf("root_only is running!\n");
}
