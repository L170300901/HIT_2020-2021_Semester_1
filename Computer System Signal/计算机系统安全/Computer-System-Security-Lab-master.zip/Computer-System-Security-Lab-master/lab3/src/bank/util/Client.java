package bank.util;

public class Client extends User {
	// 余额
	private long deposit;

	public long getDeposit() {
		return deposit;
	}

	public void setDeposit(long deposit) {
		this.deposit = deposit;
	}
	
}
