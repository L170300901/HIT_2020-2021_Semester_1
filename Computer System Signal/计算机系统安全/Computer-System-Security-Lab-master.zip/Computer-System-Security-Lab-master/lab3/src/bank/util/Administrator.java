package bank.util;

public class Administrator extends User {
	
}
