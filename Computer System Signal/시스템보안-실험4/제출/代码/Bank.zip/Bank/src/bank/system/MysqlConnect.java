package bank.system;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

import bank.util.*;

public class MysqlConnect {
	
	// JDBC �����������ݿ� URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
//    static final String DB_URL = "jdbc:mysql://localhost:3306/cocom.mysql.cj.jdbc.Drivermputer_system_security?serverTimezone=GMT%2B8";
    static final String DB_URL = "jdbc:mysql://localhost:3306/bank?useSSL=false&serverTimezone=UTC";
 
    // ���ݿ���û��������룬��Ҫ�����Լ�������
    static final String USER = "root";
    static final String PASS = "199811";
  
    public static void main(String[] args) {
    	getClientInformation();
    	System.out.println("����Ա��Ϣ��");
    	getManagerInformation();
    	System.out.println("�˵���Ϣ��");
    	getBillInformation();
    	System.out.println("�����û���Ϣ"); 
    	Client client = new Client();
    	client.setUserName("client");
    	client.setUserPassword("123456");
    	client.setDeposit(0);
    	insertClient(client);
    	System.out.println("�������Ա��Ϣ");
    	Administrator administrator = new Administrator();
    	administrator.setUserName("admin");
    	administrator.setUserPassword("123456");
    	insertManager(administrator);
    }
    
    // ��ѯ�û�����Ӧ������
    public static void getClientInformation() {
    	Information.clients = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT id, name, password, money FROM client_info";
            ResultSet rs = stmt.executeQuery(sql);
            // չ����������ݿ�
            while(rs.next()){
                // ͨ���ֶμ���
                long id  = rs.getLong("id");
                String name = rs.getString("name");
                String password = rs.getString("password");
                int money = rs.getInt("money");
                	
                Client client = new Client();
                client.setDeposit(money);
                client.setId(id);
                client.setUserName(name);
                client.setUserPassword(password);
                // �洢����
                Information.clients.add(client);
            }
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }
    
    // ��ѯ����Ա�û���Ӧ������
    public static void getManagerInformation() {
    	Information.administrators = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT id, name, password FROM manager_info";
            ResultSet rs = stmt.executeQuery(sql);
            // չ����������ݿ�
            while(rs.next()){
                // ͨ���ֶμ���
                long id  = rs.getLong("id");
                String name = rs.getString("name");
                String password = rs.getString("password");
    
                Administrator administrator = new Administrator();
                administrator.setId(id);
                administrator.setUserName(name);
                administrator.setUserPassword(password);
                // �洢����
                Information.administrators.add(administrator);
            }
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }
    
    // ��ѯδ�������˵���Ϣ
    public static void getBillInformation() {
    	Information.bills = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT id,client_id, name, money FROM bill_waiting_deal";
            ResultSet rs = stmt.executeQuery(sql);
            // չ����������ݿ�
            while(rs.next()){
                // ͨ���ֶμ���
                int id  = rs.getInt("id");
                int client_id = rs.getInt("client_id");
                String name = rs.getString("name");
                int money  = rs.getInt("money");
    
                Bill bill = new Bill();
                bill.setId(id);
                bill.setClient_id(client_id);
                bill.setName(name);
                bill.setMoney(money);
                // �洢����
                Information.bills.add(bill);
            }
            // ��ɺ�ر�
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }
    
    // ɾ�������˵�
    public static void deleteBill(String delete_bill_id) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "delete FROM bill_waiting_deal where id = " + delete_bill_id;
            int rs = stmt.executeUpdate(sql);
            if (rs > 0) {
				System.out.println("ɾ���ɹ�!!!");
			} else {
				System.out.println("ɾ��ʧ��!!!");
			}
            // ��ɺ�ر�
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }
    
    // �����˵���Ϣ
    public static int insertBill(Bill bill) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            Random rand = new Random();
            int id = rand.nextInt(100000)+ 1; 
            sql = "insert into bill_waiting_deal(id, client_id, name, money) values(" + 
            		"'" + id + "', '" + bill.getClient_id() + "', '" + bill.getName() +"', '" + bill.getMoney() + "')";
            int rs = stmt.executeUpdate(sql);
            if (rs > 0) {
				System.out.println("�������ݳɹ�!!!");
				stmt.close();
	            conn.close();
				return id;
			} else {
				System.out.println("��������ʧ��!!!");
			}
            // ��ɺ�ر�
            stmt.close();
            conn.close();
            return 0;
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return 0;
    }
    
    // �������ݿ�Ĵ����Ϣ
    public static void updateDeposit(long client_id, long deposit) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            sql = "update client_info set money = '" + deposit + "' where id = '" + client_id + "'";
            int rs = stmt.executeUpdate(sql);
            if (rs > 0) {
				System.out.println("���´��ɹ�!!!");
			} else {
				System.out.println("���´��ʧ��!!!");
			}
            // ��ɺ�ر�
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }
    
    // �����û���Ϣ
    public static int insertClient(Client client) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            Random rand = new Random();
            int id = rand.nextInt(100000)+ 1; 
            sql = "insert into client_info(id, name, password, money) values(" + 
            	"'" + id + "', '" + client.getUserName() + "', '" + client.getUserPassword() +"', '" + client.getDeposit() + "')";
            int rs = stmt.executeUpdate(sql);
            if (rs > 0) {
				System.out.println("�������ݳɹ�!!!");
				stmt.close();
	            conn.close();
				return id;
			} else {
				System.out.println("��������ʧ��!!!");
			}
            // ��ɺ�ر�
            stmt.close();
            conn.close();
            return 0;
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return 0;
    }
    
    // ���ӹ���Ա��Ϣ
    public static int insertManager(Administrator administrator) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // ע�� JDBC ����
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ������
            System.out.println("�������ݿ�...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        
            // ִ�в�ѯ
            stmt = conn.createStatement();
            String sql;
            Random rand = new Random();
            int id = rand.nextInt(100000)+ 1; 
            sql = "insert into manager_info(id, name, password) values(" + 
            	"'" + id + "', '" + administrator.getUserName() + "', '" + administrator.getUserPassword() + "')";
            int rs = stmt.executeUpdate(sql);
            if (rs > 0) {
				System.out.println("�������ݳɹ�!!!");
				stmt.close();
	            conn.close();
				return id;
			} else {
				System.out.println("��������ʧ��!!!");
			}
            // ��ɺ�ر�
            stmt.close();
            conn.close();
            return 0;
        }catch(SQLException se){
            // ���� JDBC ����
            se.printStackTrace();
        }catch(Exception e){
            // ���� Class.forName ����
            e.printStackTrace();
        }finally{
            // �ر���Դ
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// ʲô������
            try{
                if(conn!=null) 
                	conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return 0;
    }
    
}