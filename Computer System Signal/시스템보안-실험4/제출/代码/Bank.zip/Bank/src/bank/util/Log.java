package bank.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Log {
	public static FileOutputStream output;
	public Log() {
		// ����־
		try {
			File f = new File("log.txt");
            if (f.exists()) {  
                System.out.print("�ļ�����");  
            } else {  
                System.out.print("�ļ�������");  
            }
            FileOutputStream output = new FileOutputStream(f, true);
            Log.output = output;
		} catch (IOException e) {
			System.out.println("����־�ļ�ʧ��");
		}
	}
}