package bank.util;

import java.util.List;

public class Information {
	public static List<Client> clients;
	public static List<Administrator> administrators;
	public static List<Bill> bills;
}
